package softwareCraftsmanship;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MarsRoverSpecs {

	@Test
	public void test() {

		String initialPosition = "3 3 E";
		String commandSequence = "MMRMMRMRRM";

		String[] positions = initialPosition.split(" ");
		int xPosition = Integer.valueOf(positions[0]);
		int yPosition = Integer.valueOf(positions[0]);
		String direction = positions[2];
		
		MarsRover rover=new MarsRover(xPosition,yPosition,direction);
		for(char command:commandSequence.toCharArray()){
			rover.move(command);
		}
		assertEquals("5 1 E",  rover.x +" "+rover.y +" "+ rover.direction); 
		
	}

}
