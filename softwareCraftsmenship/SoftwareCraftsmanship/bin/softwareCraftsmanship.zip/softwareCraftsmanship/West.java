package softwareCraftsmanship;

public class West {

	String turnLeftFromWest() {
		return "S";
	}

	String turnRightFromWest() {
		return "N";
	}

	int moveForwardFromWest(int xPosition) {
		return xPosition--;
	}

}
