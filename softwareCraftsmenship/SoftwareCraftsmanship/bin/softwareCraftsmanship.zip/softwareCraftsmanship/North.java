package softwareCraftsmanship;

public class North {

	String turnLeft() {
		return "W";
	}

	String turnRight() {
		return "E";
	}

	int moveForward(int yPosition) {
		return yPosition + 1;
	}
	
}
