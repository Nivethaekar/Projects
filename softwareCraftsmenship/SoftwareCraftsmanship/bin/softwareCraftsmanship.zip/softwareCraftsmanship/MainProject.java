package softwareCraftsmanship;

public class MainProject {
	
	public static void main(String args[]){
		Car car=new Car(2);
		car.addPosition(3);
		car.printPositionOfCar(car);
	}

}
