package softwareCraftsmanship;

public class MarsRover {

	int x = 0;
	int y = 0;
	String direction = "";

	public MarsRover(int xPosition, int yPosition, String direction) {
		this.x = xPosition;
		this.y = yPosition;
		this.direction = direction;
	}

	void move(char command) {
		if (direction.equalsIgnoreCase("N")) {
			North north=new North();
			switch (command) {
			case 'L':
				direction = north.turnLeft();
				break;
			case 'R':
				direction = north.turnRight();
				break;
			case 'M':
				Position position=new Position(x,y);
				position = north.moveForward(position);
				break;
			}
		} else if (direction.equalsIgnoreCase("E")) {
			East east=new East();
			switch (command) {
			case 'L':
				direction = east.turnLeft();
				break;
			case 'R':
				direction = east.turnRight();
				break;
			case 'M':
				x = east.moveForward(this.x);
				break;
			}
		} else if (direction.equalsIgnoreCase("S")) {
			South south=new South();
			switch (command) {
			case 'L':
				direction = south.turnLeftFromSouth();
				break;
			case 'R':
				direction = south.turnRightFromSouth();
				break;
			case 'M':
				y = south.moveForwardFromSouth(this.y);
				break;
			}
		} else if (direction.equalsIgnoreCase("W")) {
			West west=new West();
			switch (command) {
			case 'L':
				direction = west.turnLeftFromWest();
				break;
			case 'R':
				direction = west.turnRightFromWest();
				break;
			case 'M':
				x = west.moveForwardFromWest(this.x);
				break;
			}
		}
	}

}
