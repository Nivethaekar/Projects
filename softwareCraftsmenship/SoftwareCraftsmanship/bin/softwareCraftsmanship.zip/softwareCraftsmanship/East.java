package softwareCraftsmanship;

public class East {

	String turnLeft() {
		return "N";
	}

	String turnRight() {
		return "S";
	}

	int moveForward(int xPosition) {
		return xPosition + 1;
	}}
