package softwareCraftsmanship;

public class South {

	String turnLeftFromSouth() {
		return "E";
	}

	String turnRightFromSouth() {
		return "W";
	}

	int moveForwardFromSouth(int yPosition) {
		return yPosition--;
	}

}
